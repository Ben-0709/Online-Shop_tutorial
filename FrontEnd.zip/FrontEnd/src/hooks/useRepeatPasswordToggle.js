import React, {useState} from 'react';
import VisibilityIcon from '@mui/icons-material/Visibility';
import VisibilityOffIcon from '@mui/icons-material/VisibilityOff';

const useRepeatPasswordToggle = () => {
    const [visible, setVisible] = useState(false);
    const icon = (
        <b onClick={() => setVisible(!visible)}>
            {visible ? <VisibilityIcon/> : <VisibilityOffIcon/>}
        </b>
    )
    const inputType = visible ? 'text' : 'password';
    return [inputType, icon];
}
export default useRepeatPasswordToggle;