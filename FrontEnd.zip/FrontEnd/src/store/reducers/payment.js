import { createReducer } from "@reduxjs/toolkit";
import { payToken, payConfirm } from "../actions/payment";


const initialState = {
payData: []    
}



export default createReducer(initialState, {
[payConfirm.pending]: (state, action) => {

},
[payConfirm.pending]: (state, action) => {
console.log(action)
},
[payConfirm.pending]: (state, action) => {

},
})