import { createReducer } from "@reduxjs/toolkit";
import { createRating } from "../actions/rating";

const initialState = {
 rate: []   
}


export default createReducer(initialState, {
  [createRating.fulfilled]: (state, action) => {
    console.log(action)
  }  
})



