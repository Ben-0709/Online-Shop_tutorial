import {createAsyncThunk} from "@reduxjs/toolkit"
import {useCallback} from "react"
import Api from "../../Api"


export const getProducts = createAsyncThunk('action/products/getProducts', async () => {
    const {data} = await Api.getData();
    return data;
})


export const searchProducts = createAsyncThunk('action/products/searchProducts', async (payload) => {
    const {data} = await Api.searchProducts(payload);
    return data;
})

export const singleProduct = createAsyncThunk('action/products/singleProduct', async (id) => {
    const {data} = await Api.singleProduct(id);
    return data;
})

export const addProduct = createAsyncThunk('action/products/addProduct', async (payload) => {
    const {data} = await Api.addProduct(payload);
    return data;
})

export const delProduct = createAsyncThunk('action/products/delProduct', async (id) => {
    const {data} = await Api.deleteProduct(id);
    return data;
})


