import { createAsyncThunk } from "@reduxjs/toolkit";
import Api from "../../Api";


export const createRating = createAsyncThunk('/action/rating/createRating', async(payload) => {
    const {data} = await Api.rating(payload)
    return data
})