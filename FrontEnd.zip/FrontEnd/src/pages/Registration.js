import React, {useCallback, useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import {toast, ToastContainer} from 'react-toastify';
import {register} from '../store/actions/registration';
import {useNavigate, Link} from 'react-router-dom';
import HomeIcon from '@mui/icons-material/Home';
import usePasswordToggle from "../hooks/usePasswordToggle";
import useRepeatPasswordToggle from "../hooks/useRepeatPasswordToggle";
import Helmet from "react-helmet";


export default function Registration() {
    const navigate = useNavigate();
    const dispatch = useDispatch();
    const [fName, setFName] = useState('');
    const [lName, setLName] = useState('');
    const [userName, setUserName] = useState('');
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [rePassword, setRePassword] = useState('');
    const [age, setAge] = useState('');
    const [PasswordInputType, ToggleIcon] = usePasswordToggle();
    const [RepeatPasswordInputType, RepeatToggleIcon] = useRepeatPasswordToggle();
    const [passwordFocused, setPasswordFocused] = useState(false);
    const [passwordValidity, setPasswordValidity] = useState({
        minChar: null,
        number: null,
        specialChar: null,
    });
    const isNumberRegx = /\d/;
    const specialCharacterRegx = /[ !@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/;
    const onChangePassword = useCallback((password) => {
        setPassword(password);
        setPasswordValidity({
            minChar: password.length >= 8,
            number: isNumberRegx.test(password),
            specialChar: specialCharacterRegx.test(password)
        });
    }, [password]);

    const onChangeRePassword = useCallback((password) => {
        setRePassword(password);
        setPasswordValidity({
            minChar: password.length >= 8,
            number: isNumberRegx.test(password),
            specialChar: specialCharacterRegx.test(password)
        });
    }, [password]);

    const handleSubmit = useCallback(async (ev) => {
        ev.preventDefault();
        if (password !== rePassword) {
            toast.error('Password is not unique')
            return;
        }
        const data = await dispatch(register({
            fname: fName,
            lname: lName,
            email: email,
            username: userName,
            password: password,
            age: age,
            role: "6",
        }))
        navigate('/account');
        console.log(data);
    }, [fName, lName, password, userName, age, email, rePassword]);

    return (
        <>
            <Helmet>
                <title>H-E-B Registration page</title>
            </Helmet>
            <div className='registrationPage'>
                <div className="container">
                    <div className="registrationBox">
                        <Link to='/' className="home">
                            <HomeIcon style={{fontSize: 30, verticalAlign: 'sub'}}/>
                        </Link>
                        <form onSubmit={(ev) => handleSubmit(ev)}>
                            <h2>Registration</h2>
                            <div className="registrationInputBox">
                                <input value={fName} onChange={(ev) => setFName(ev.target.value)} type="text"
                                       required="required"/>
                                <span data-name='name'>First name</span>
                                <i/>
                            </div>
                            <div className="registrationInputBox">
                                <input value={lName} onChange={(ev) => setLName(ev.target.value)} type="text"
                                       required="required"/>
                                <span data-name='name'>Last name</span>
                                <i/>
                            </div>
                            <div className="registrationInputBox">
                                <input value={email} onChange={(ev) => setEmail(ev.target.value)} type="email"
                                       required="required"/>
                                <span data-name='name'>Email</span>
                                <i/>
                            </div>
                            <div className="registrationInputBox">
                                <input value={age} onChange={(ev) => setAge(ev.target.value)} type="number" min='18'
                                       max='100' required="required"/>
                                <span data-name='name'>Age</span>
                                <i/>
                            </div>
                            <div className="registrationInputBox">
                                <input value={userName} onChange={(ev) => setUserName(ev.target.value)} type="text"
                                       required="required"/>
                                <span data-name='name'>Nick name</span>
                                <i/>
                            </div>
                            <div className="registrationInputBox">
                                <input value={password}
                                       type={PasswordInputType}
                                       onFocus={() => setPasswordFocused(true)}
                                       onChange={(e) => onChangePassword(e.target.value)}
                                       required="required"/>
                                <span data-name='name'>Password</span>
                                <i/>
                                <span className="password-toggle-icon">
                                {ToggleIcon}
                            </span>
                            </div>
                            <div className="registrationInputBox last">
                                <input value={rePassword}
                                       onFocus={() => setPasswordFocused(true)}
                                       onChange={(e) => onChangeRePassword(e.target.value)}
                                       type={RepeatPasswordInputType}
                                       required="required"/>
                                <span data-name='name'>Repeat Password</span>
                                <ToastContainer/>
                                <i/>
                                <span className="password-toggle-icon">
                                {RepeatToggleIcon}
                            </span>
                            </div>
                            <div className="links">
                                <Link to="/account">Sign in</Link>
                            </div>
                            <input type="submit"
                                   className='submitInput'
                                   value="Confirm"/>
                        </form>
                    </div>
                </div>
            </div>
        </>
    )
}