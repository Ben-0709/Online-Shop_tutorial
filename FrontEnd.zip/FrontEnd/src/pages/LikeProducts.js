import {useDispatch, useSelector} from 'react-redux';
import {likeList, removeLike} from '../store/actions/likeProducts';
import Header from '../components/Header';
import Footer from '../components/Footer';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import React, {useCallback, useEffect, useState} from 'react'
import Spinner from 'react-bootstrap/Spinner';
import {toast} from 'react-toastify';
import {useNavigate} from 'react-router-dom';
import {basketCreate, basketList} from '../store/actions/basket';
import DeleteIcon from '@mui/icons-material/Delete';
import {Link} from 'react-router-dom';
import Toast from '../components/tiny-components/Toast';
import Card from "react-bootstrap/Card";
import GoToTop from "../components/tiny-components/GoToTop";
import Helmet from "react-helmet";
import CurrencyFormat from "../components/tiny-components/CurrencyFormat";

export default function LikeProducts() {
    const [load, setLoad] = useState(true);
    const likes = useSelector((state) => state.likes.likes);
    const dispatch = useDispatch();
    const navigate = useNavigate();
    const token = localStorage.getItem("userToken");
    const userData = JSON.parse(localStorage.getItem("userData"));
    const basket = useSelector((state) => state.basket.basket);

    useEffect(() => {
        (async () => {
            setLoad(true)
            await dispatch(likeList())
            setLoad(false)
        })();
    }, [likeList])

    console.log(likes)

    const handleClick = useCallback(async (el) => {
        let error = false;
        const prodId = basket.map((id) => (id.product_id));

        if (prodId.find((id) => id === el.product_id)) {
            error = true
            toast.error('Item already in cart!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
        }


        if (!userData) {
            toast.error('Please login to be add card!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
            return
        } else if (error) {
            return
        }


        const data = await dispatch(basketCreate({
            user_id: userData.id,
            product_id: el.product.id,
            quantity: el.product.quantity,
            price: el.product.price
        }))

        if (data.payload) {
            toast.success(`${el.product.title} added in your basket`, {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "light",
            });
        }
        await dispatch(basketList())
    }, [userData])


    const singleItem = useCallback((item) => {
        navigate(`/home/${item.id}`)
    }, [])

    const handleDelete = useCallback(async (el) => {
        await dispatch(removeLike(el));
        await dispatch(likeList());
    }, [])


    return (
        <>
            <Helmet>
                <title>H-E-B Wishlist page</title>
            </Helmet>
            <Toast/>
            <Header/>
            <GoToTop/>
            {token ?
                <>
                    <div className='main'>
                        {!load ?
                            <div className='container'>
                                {likes.length ?
                                    <div className='cardStyle'>
                                        {likes.map((item) => (
                                            <div key={item.product.id} className='cardItem'>
                                                <Card onClick={() => singleItem(item.product)} className="card">
                                                    <figure className='figure'>
                                                        <Card.Img variant="top"
                                                                  alt="Product image"
                                                                  className="productImage"
                                                                  src={item.product.image}/>
                                                        <Card.Body className="cardBody">
                                                            <Card.Title className="cardTitle">
                                                            <span>
                                                                 {item.product.title}
                                                            </span>
                                                            </Card.Title>
                                                            <Card.Text className="cardPrice">
                                                                <CurrencyFormat value={item.product.price}
                                                                                currency='USD'/>
                                                            </Card.Text>
                                                            <div className="cartButtons">
                                                                <button className='addButton'
                                                                        onClick={(e) => handleClick(item, e.stopPropagation())}>
                                                                    <AddShoppingCartIcon style={{fontSize: 35}}/>
                                                                </button>
                                                                <button className='removeButton'
                                                                        onClick={(e) => handleDelete(item.id, e.stopPropagation())}>
                                                                    <DeleteIcon style={{fontSize: 35}}/>
                                                                </button>
                                                            </div>
                                                        </Card.Body>
                                                    </figure>
                                                </Card>
                                            </div>
                                        ))}

                                    </div>
                                    :
                                    <section className='emptyWishPanel'>
                                        <h1 className='emptyWishPanelTitle'>Your wish❤list is Empty.</h1>
                                        <p className='emptyWishPanelDesc'>
                                            Look at the main page to select products
                                            or find what you need in the search. </p>
                                        <Link to='/' className='emptyWishPanelButton'>Home Page</Link>
                                    </section>
                                }
                            </div>
                            :
                            <div className='spL'>
                                <Spinner className='spinnerLoad' animation="border" variant="dark"/>
                            </div>
                        }
                    </div>
                </>
                :
                <div className='container'>
                    <section className='wishPanel'>
                        <h1 className='wishPanelTitle'>Wish❤️list unavailable.</h1>
                        <p className='wishPanelDesc'> Please log in to see the items on your wish list. </p>
                        <Link to='/account' className='wishPanelButton'>Login</Link>
                    </section>
                </div>
            }
            <Footer/>
        </>
    )
}
