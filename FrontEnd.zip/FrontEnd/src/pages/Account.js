import React, {useCallback, useState} from 'react';
import {login} from '../store/actions/login';
import {Link, useNavigate} from 'react-router-dom';
import {useDispatch, useSelector} from 'react-redux';
import {toast} from 'react-toastify';
import HomeIcon from '@mui/icons-material/Home';
import Toast from '../components/tiny-components/Toast';
import Helmet from 'react-helmet';
import usePasswordToggle from "../hooks/usePasswordToggle";


export default function Account() {
    const [logValue, setLogValue] = useState('');
    const [pasValue, setPasValue] = useState('');
    const [PasswordInputType, ToggleIcon] = usePasswordToggle();
    const [passwordFocused, setPasswordFocused] = useState(false);
    const [passwordValidity, setPasswordValidity] = useState({
        minChar: null,
        number: null,
        specialChar: null
    });

    const dispatch = useDispatch();
    const signIn = useSelector((state) => state.login.users);
    const token = useSelector((state) => state.login.token);
    const navigate = useNavigate();
    const error = 'Invalid email or password';

    const isNumberRegx = /\d/;
    const specialCharacterRegx = /[ !@#$%^&*()_+\-=[\]{};':"\\|,.<>/?]/;
    const onChangePassword = (password) => {
        setPasValue(password);
        setPasswordValidity({
            minChar: password.length >= 8,
            number: isNumberRegx.test(password),
            specialChar: specialCharacterRegx.test(password)
        });
    };

    const handleSubmit = useCallback(async (ev) => {
        ev.preventDefault();
        const data = await dispatch(login({
            email: logValue,
            password: pasValue,
        }))
        if (!data.payload) {
            toast.error(error);
            setPasValue('');
            return false;
        }
        navigate('/home');
    }, [logValue, pasValue]);

    return (
        <>
            <Helmet>
                <title>Sign-in page</title>
            </Helmet>
            <div className='signInPage'>
                <div className="container">
                    <div className="box">
                        <Link to='/' className="home">
                            <HomeIcon style={{fontSize: 30, verticalAlign: 'sub'}}/>
                        </Link>
                        <form onSubmit={(ev) => handleSubmit(ev)}>
                            <h2>Sign in</h2>
                            <div className="inputBox">
                                <input value={logValue}
                                       onChange={(ev) => setLogValue(ev.target.value)}
                                       type="email"
                                       required="required"/>
                                <span data-name='name'>Email</span>
                                <i/>
                            </div>
                            <div className="inputBox password">
                                <input value={pasValue}
                                       type={PasswordInputType}
                                       onFocus={() => setPasswordFocused(true)}
                                       onChange={(ev) => onChangePassword(ev.target.value)}
                                       required="required"/>
                                <span data-name='name'>Password</span>
                                <i/>
                                <span className="password-toggle-icon">
                                {ToggleIcon}
                            </span>
                            </div>
                            <div className="links">
                                <Link to="/register">Sign up</Link>
                            </div>
                            <input type="submit" value="Login"/>
                        </form>
                        <Toast/>
                    </div>
                </div>
            </div>
        </>
    )
}
