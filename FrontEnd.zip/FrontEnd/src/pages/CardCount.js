import React, {useCallback, useEffect, useState} from 'react'
import {useDispatch, useSelector,} from 'react-redux'
import {basketList, basketRemove} from '../store/actions/basket'
import Toast from '../components/tiny-components/Toast';
import PaidIcon from '@mui/icons-material/Paid';
import {useNavigate} from 'react-router-dom';
import Table from 'react-bootstrap/Table';
import {Tooltip} from "@mui/material";
import DeleteIcon from '@mui/icons-material/Delete';
import GoToTop from "../components/tiny-components/GoToTop";
import Helmet from "react-helmet";
import CurrencyFormat from "../components/tiny-components/CurrencyFormat";
import Spinner from "react-bootstrap/Spinner";

export default function CardCount({b}) {
    const dispatch = useDispatch();
    const [count, setCount] = useState(1);
    const navigate = useNavigate();
    const [loading, setLoading] = useState(true);
    const basket = useSelector((state) => state.basket.basket);
    const [isDisabledDecrement, setIsDisabledDecrement] = useState(false);
    const [isDisabledIncrement, setIsDisabledIncrement] = useState(false);

    useEffect(() => {
        (async () => {
            setLoading(true);
            await dispatch(basketList())
            setLoading(false);
        })();
        setIsDisabledDecrement(true);
    }, [basketList])

    const handleDelete = useCallback(async (el) => {
        await dispatch(basketRemove(el));
        await dispatch(basketList());
    }, []);


    const handlePlus = useCallback((el) => {
        if (count >= el.quantity) {
            setIsDisabledIncrement(true);
            return null;
        } else {
            setCount(count + 1)
        }
        setIsDisabledDecrement(false);
    }, [count]);

    const handleMinus = useCallback((el) => {
        if (count === 1) {
            return setIsDisabledDecrement(true);
        } else {
            setCount(count - 1)
        }
        const newCount = count - 1;
        setCount(newCount);
        setIsDisabledIncrement(false);
        setIsDisabledDecrement(false);
    }, [count]);


    const handleBuy = useCallback((el) => {
        console.log(el);
        navigate('/payment');
    }, []);


    const singleItem = useCallback((item) => {
        navigate(`/home/${item}`)
    }, []);

    const disabled = {
        opacity: 0.4,
        verticalAlign: 3,
        border: 0,
    }


    return (
        <>
            <Helmet>
                <title>Cart panel</title>
            </Helmet>
            <Toast/>
            <GoToTop/>
            <div className="main" style={{justifyContent: 'center'}}>
                {!loading ?
                    <div className='table' key={b.product.id}>
                        {b.product
                            ?
                            <div className="container">
                                <Table striped bordered hover>
                                    <tbody onClick={() => singleItem(b.product_id)}>
                                    <tr key={b.product_id}>
                                        <td>
                                            <img src={b.product.image} alt=''/>
                                        </td>
                                        <td className="column__content">
                                            <td>
                                                <span>
                                                    {b.product.title}
                                                </span>
                                            </td>
                                            <td className='price'>
                                                <CurrencyFormat value={b.product.price} currency='USD'/>
                                            </td>
                                        </td>
                                        <td>
                                            <button
                                                className='decrementButton'
                                                style={isDisabledDecrement ? disabled : null}
                                                onClick={(e) => {
                                                    e.stopPropagation()
                                                    handleMinus(b.quantity)
                                                }}
                                                disabled={isDisabledDecrement}>-
                                            </button>
                                            <span id='count'> {count} </span>
                                            <Tooltip title="Increment button!" arrow placement='right'>
                                                <button
                                                    className='incrementButton'
                                                    style={isDisabledIncrement ? disabled : null}
                                                    disabled={isDisabledIncrement}
                                                    onClick={(e) => {
                                                        e.stopPropagation()
                                                        handlePlus(b)
                                                    }}>+
                                                </button>
                                            </Tooltip>
                                        </td>
                                        <td>
                                            <Tooltip title="Delete!" arrow placement='bottom'>
                                                <button
                                                    className='removeIcon'
                                                    onClick={(e) => handleDelete(b.id, e.stopPropagation())}>
                                                    <DeleteIcon/>
                                                </button>
                                            </Tooltip>
                                            <Tooltip title="Pay!" arrow placement='bottom'>
                                                <button
                                                    className='paidIcon'
                                                    onClick={(e) => handleBuy(b, e.stopPropagation())}>
                                                    <PaidIcon/>
                                                </button>
                                            </Tooltip>
                                        </td>
                                    </tr>
                                    </tbody>
                                </Table>
                            </div>
                            : null}
                    </div>
                    :
                    <div className='spL'>
                        <Spinner className='spinnerLoad' animation="border" variant="dark"/>
                    </div>
                }
            </div>
        </>
    )
}
