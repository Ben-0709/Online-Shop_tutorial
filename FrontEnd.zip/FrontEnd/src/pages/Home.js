import React from 'react';
import Wrapper from '../components/Wrapper';
import Footer from '../components/Footer';
import Header from '../components/Header';
import AdminHeader from '../components/AdminHeader';
import AdminWrapper from '../components/AdminWrapper';
import Helmet from "react-helmet";

export default function Home() {
const user = JSON.parse(localStorage.getItem("userData"));

console.log(user)
    return (
        <>
            <Helmet>
                <title>H-E-B online store</title>
            </Helmet>
             {user && user.role === 2 ? <AdminHeader/> : <Header />}
           {user && user.role === 2 ? <AdminWrapper/> : <Wrapper/>}
             {user && user.role === 2 ? null : <Footer />   }       
        </>
    )
}
