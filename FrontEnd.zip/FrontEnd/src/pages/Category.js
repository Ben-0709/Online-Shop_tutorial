import React, {useCallback, useEffect, useState} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import Header from '../components/Header';
import Footer from '../components/Footer';
import {getProducts} from '../store/actions/products';
import {Link, useNavigate, useParams} from 'react-router-dom';
import {prodCategory} from '../store/actions/productCategory';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import {toast} from 'react-toastify';
import {basketCreate, basketList} from '../store/actions/basket';
import {likeProduct, likeList} from '../store/actions/likeProducts';
import Toast from '../components/tiny-components/Toast';
import AdminHeader from '../components/AdminHeader'
import GoToTop from "../components/tiny-components/GoToTop";
import CurrencyFormat from "../components/tiny-components/CurrencyFormat";
import Card from "react-bootstrap/Card";
import FavoriteOutlinedIcon from "@mui/icons-material/FavoriteOutlined";
import FavoriteBorderOutlinedIcon from "@mui/icons-material/FavoriteBorderOutlined";
import ReactStars from "react-rating-stars-component";
import {createRating} from "../store/actions/rating";


export default function Category() {
    const dispatch = useDispatch();
    const products = useSelector((state) => state.category.products);
    const user = JSON.parse(localStorage.getItem("userData"));
    const {cat_id} = useParams();
    const navigate = useNavigate();
    const basket = useSelector((state) => state.basket.basket);
    const likes = useSelector((state) => state.likes.likes);
    const [loading, setLoading] = useState(true);
    const userData = JSON.parse(localStorage.getItem("userData"));
    const [rating, setRating] = useState(0);
    let error = false;

    useEffect(() => {
        (async () => {
            setLoading(true);
            await dispatch(getProducts());
            setLoading(false);
        })();
    }, [getProducts]);

    const singleItem = useCallback((item) => {
        navigate(`/home/${item.id}`)
    }, [])

    useEffect(() => {
        (async () => {
            await dispatch(prodCategory(cat_id));
        })();
    }, []);

    const handleClick = useCallback(async (el) => {
        const prodId = basket.map((id) => (id.product_id))
        if (prodId.find((id) => id === el.id)) {
            error = true
            toast.error('Item already in cart!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }


        if (!user) {
            toast.error('Please login to be add card!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
            return;
        } else if (error) {
            return;
        }


        const data = await dispatch(basketCreate({
            user_id: user.id,
            product_id: el.id,
            quantity: el.quantity,
            price: el.price
        }))

        if (data.payload) {
            toast.success(`${el.title} added in your basket`, {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }
        await dispatch(basketList());
    }, [user]);


    const handleLike = useCallback(async (el) => {
        const likeId = likes.map((id) => (id.product_id));
        if (likeId.find((id) => id === el.id)) {
            error = true
            toast.error('Item already in your wishlist!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }

        if (!user) {
            toast.error('Please login to be add item in your wishlist!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
            return;
        } else if (error) {
            return;
        }

        const data = await dispatch(likeProduct({
            product_id: el.id,
            user_id: user.id
        }))
        if (data.payload) {
            toast(`${el.title} added in your wishlist`)
        }
        await dispatch(likeList());
    }, [user]);

    const handleRating = useCallback(async (element) => {
        const data = await dispatch(createRating({
            product_id: element.id,
            user_id: userData.id,
            rate: rating,
        }))
        console.log(data)
    }, [rating])


    const handleRate = useCallback((el) => {
        if (el !== 0) {
            setRating(el);
        } else {
            return;
        }
        console.log(rating);
    }, [rating]);

    return (
        <div>
            {user && user.role === 2 ? <AdminHeader/> : <Header/>}
            <Toast/>
            {products.length ?
                <div className='cardStyle'>
                    {products.map((product) => (
                        <div key={product.id} className='cardItem'>
                            <Card onClick={() => singleItem(product)} className="card">
                                <figure className='figure'>
                                    <Card.Img variant="top"
                                              alt="Cart image cap"
                                              className="productImage"
                                              src={product.image}/>
                                    <button className='likeButton'
                                            onClick={(e) => handleLike(product, e.stopPropagation())}>
                                        <FavoriteBorderOutlinedIcon
                                            style={{fontSize: 35, display: 'flex', color: 'red'}}/>
                                    </button>
                                    <Card.Body className="cardBody">
                                        <Card.Title className="cardTitle">
                                            <span>
                                                {product.title}
                                            </span>
                                        </Card.Title>
                                        <Card.Text className="cardPrice">
                                            <CurrencyFormat value={product.price} currency='USD'/>
                                        </Card.Text>
                                        <button onClick={(e) => handleRating(product, e.stopPropagation())}
                                                className='stars'>
                                            <ReactStars
                                                count={5}
                                                size={25}
                                                value={rating}
                                                // color='rgb(3, 151, 232)'
                                                isHalf
                                                classNames='starStyle'
                                                activeColor="#ffd700"
                                                onChange={handleRate}
                                            />
                                        </button>
                                        <button
                                            className='addToCartButton'
                                            onClick={(e) => handleClick(product, e.stopPropagation())}>
                                            <AddShoppingCartIcon
                                                style={{fontSize: 25, verticalAlign: 'middle'}}/>
                                            Add to cart
                                        </button>
                                    </Card.Body>
                                </figure>
                            </Card>
                        </div>
                    ))}
                    <GoToTop/>
                </div>
                :
                <div className='container'>
                    <section className='emptyWishPanel'>
                        <h1 className='emptyWishPanelTitle'>Products in this category Empty</h1>
                        <p className='emptyWishPanelDesc'>
                            Look at the main page to select products
                            or find what you need in the search. </p>
                        <Link to='/' className='emptyWishPanelButton'>Home Page</Link>
                    </section>
                </div>
            }
            {user && user.role === 2 ? null : <Footer/>}
        </div>
    )
}
