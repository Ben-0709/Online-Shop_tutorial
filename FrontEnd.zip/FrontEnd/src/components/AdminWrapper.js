import React, { useCallback, useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { useNavigate } from 'react-router-dom'
import { getProducts } from '../store/actions/products'
import RemoveShoppingCartIcon from '@mui/icons-material/RemoveShoppingCart';
import { delCategory } from '../store/actions/productCategory';
import { delProduct } from '../store/actions/products';
import { toast } from 'react-toastify';
import Toast from './tiny-components/Toast';



export default function AdminWrapper() {

  const dispatch = useDispatch()
  const navigate = useNavigate()
  const products = useSelector((state) => state.products.productsData);

  console.log(products)

  useEffect(() => {

    (async () => {
      await dispatch(getProducts())
    })()

  }, [getProducts])






  const singleItem = useCallback((el) => {

    console.log(el)

  }, [])


  const handleDelete = useCallback(async(pr) => {

    const data = await dispatch(delProduct(pr))
if(data.payload){
  toast('Product Succesfully deleted')
}
await dispatch(getProducts())


  }, [])


  return (
    <div className='cardStyle'>
      <Toast/>
      <div className='cardItem'>
        {products.map((item) => (
          <div onClick={() => singleItem(item)} className="card">
            <figure className='figure'>
              <img className="card-img-top" src={item.image} alt="Cart image cap" />
              <figcaption className="card-body">
              <h5 className="card-title">{item.title}</h5>
              <p className="card-text desc">{item.short_desc}</p>
              <p className="card-text">{item.price + '$'}</p>
              <button onClick={(e) => handleDelete(item.id, e.stopPropagation())}>
                Delete Product <RemoveShoppingCartIcon/>
              </button>
              </figcaption>
              </figure>

          </div>
        ))}
      </div>

    </div>
  )
}
