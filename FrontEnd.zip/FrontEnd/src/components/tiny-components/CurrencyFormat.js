// import React from 'react';
import PropTypes from "prop-types";
import { IntlService } from "@progress/kendo-react-intl";

const fieldFormats = {
    locale: { Id: "en", Name: "EN" },
    number: "n2",
    integer: "n0",
    date: "MM/dd/yyyy",
    time: "h:mm a",
    temperature: '#,#.# "°F"',
    temperatureCell: '{0: #,#.# "°F"}',
    percent: "p2",
    price: "c2",
    uniCost: "c4",
    fiscalPeriod: "yyyy-MM",
    fiscalPeriodCell: "{0:yyyy-MM}"
};

const CurrencyFormat = (props) => {
    const intl = new IntlService(fieldFormats.locale.Id);
    const { value, currency } = props;
    // for empty value return ''
    if (value === undefined || value === null || value === "") {
        return "";
    }
    // for undefined currency use locale format
    if (currency.trim() === "") {
        return intl.formatNumber(value, fieldFormats.price, fieldFormats.locale.Id);
    }
    const newValue = intl.formatNumber(
        value,
        {
            style: "currency",
            currency
        },
        fieldFormats.locale.Id
    );
    return newValue;
};

CurrencyFormat.propTypes = {
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    currency: PropTypes.string,
    locale: PropTypes.string
};

CurrencyFormat.defaultProps = {
    currency: "USD",
    value: ""
};

export default CurrencyFormat;
