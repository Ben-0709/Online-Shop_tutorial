import React, {useEffect, useState} from 'react';
import ArrowUpwardIcon from "@mui/icons-material/ArrowUpward";

function GoToTop() {
    const [show, setShow] = useState(false);


    useEffect(() => {
        window.addEventListener('scroll', () => {
            (window.pageYOffset > 300)
                ? setShow(true)
                : setShow(false)
        });
    }, []);
    const goToTop = () => {
        window.scrollTo({
            top: 0,
            behavior: "smooth",
        });
    };
    return (
        <>
            {show && (
                <div className='top' onClick={goToTop}>
                    <ArrowUpwardIcon style={{fontSize: 30, fill: 'blue'}}/>
                </div>
            )}
        </>
    );
}

export default GoToTop;