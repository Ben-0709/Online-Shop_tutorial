import React, {useCallback, useState, useEffect} from 'react';
import {useDispatch, useSelector} from 'react-redux';
import MenuIcon from "@mui/icons-material/Menu";
import {useNavigate} from 'react-router-dom';
import {categoryList, prodCategory} from '../../store/actions/productCategory';
import {stack as Burger} from 'react-burger-menu';

function Menu() {
    const [isOpen, setIsOpen] = useState(null);
    const catList = useSelector((state) => state.category.catList);
    const category = useSelector((state) => state.category.category);
    const dispatch = useDispatch();
    const navigate = useNavigate();

    useEffect(() => {
        dispatch(categoryList());
    }, []);

    const toggle = useCallback((id) => {
        setIsOpen(isOpen === id ? null : id);
    }, [isOpen]);

    const handleClick = useCallback(async (el) => {
        const data = await dispatch(prodCategory(`${el.id}`))
        navigate(`/category/${el.id}`)
        setIsOpen(null)
    }, [])


    return (
        <div className='nav'>
            <MenuIcon style={{fontSize: 45, color: 'white'}} onClick={toggle}/>
            <Burger className="bm-menu-wrap nav">
                {
                    catList.map((items) => (
                        <ul key={items.id} className="bm-item nav__block">
                            <li className="nav__list">
                                <button onClick={() => toggle(items.id)} className="nav__link">{items.title}</button>
                            </li>
                            {isOpen === items.id ?
                                <div>
                                    {items.child.map((item) => (
                                        <ul key={item.id} className='childList'>
                                            <li>
                                                <button className='childBtn'
                                                        onClick={() => handleClick(item)}>{item.title}
                                                </button>
                                            </li>
                                        </ul>
                                    ))}
                                </div>
                                : null}
                        </ul>
                    ))
                }
            </Burger>
        </div>
    )
}


export default Menu;