import React, {useCallback, useEffect, useState} from 'react';
import {singleProduct} from '../store/actions/products';
import {useDispatch, useSelector} from 'react-redux';
import Header from './Header';
import Footer from './Footer';
import {useNavigate, useParams} from 'react-router-dom';
import AddShoppingCartIcon from '@mui/icons-material/AddShoppingCart';
import FavoriteIcon from '@mui/icons-material/Favorite';
import {toast} from 'react-toastify';
import {basketCreate, basketList} from '../store/actions/basket';
import {likeProduct, likeList} from '../store/actions/likeProducts';
import Carousel from 'nuka-carousel';
import Toast from './tiny-components/Toast';
import {prodCategory} from '../store/actions/productCategory';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import ArrowBackIosNewIcon from '@mui/icons-material/ArrowBackIosNew';
import AdminHeader from '../components/AdminHeader'
import Card from 'react-bootstrap/Card';
import ReactStars from "react-rating-stars-component";
import {createRating} from "../store/actions/rating";
import CurrencyFormat from '../components/tiny-components/CurrencyFormat';


export default function SingleProduct() {
    const {productId} = useParams();
    const product = useSelector((state) => state.products.singleProduct);
    const dispatch = useDispatch();
    const [zoom, setZoom] = useState(false);
    const [position, setPosition] = useState({x: 0, y: 0});
    const user = JSON.parse(localStorage.getItem("userData"))
    const basket = useSelector((state) => state.basket.basket)
    const likes = useSelector((state) => state.likes.likes)
    const catProd = useSelector((state) => state.category.products);
    const navigate = useNavigate();
    const [showAll, setShowAll] = useState(false);
    const [showScroll, setShowScroll] = useState(false);
    const [rating, setRating] = useState(0);
    const [loading, setLoading] = useState(true);

    useEffect(() => {
        (async () => {
            setLoading(true);
            await dispatch(singleProduct(productId));
            setLoading(false);
        })()
    }, [singleProduct, product])

    useEffect(() => {
        (async () => {
            setLoading(true);
            await dispatch(prodCategory(product.map((id) => (id.cat_id))));
            setLoading(false);
        })();
    }, [product]);

    const handleClickShowAll = useCallback(() => {
        setShowAll(true);
        setShowScroll(true);
    }, []);

    const handleClickHideAll = useCallback(() => {
        setShowAll(false);
        setShowScroll(false);
    }, []);


    const handleClick = useCallback(async (el) => {
        let error = false;
        const prodId = basket.map((id) => (id.product_id))


        if (prodId.find((id) => id === el.id)) {
            error = true
            toast.error('Item already in cart!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }

        if (!user) {
            toast.error('Please login to be add card!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
            return;
        } else if (error && user) {
            return;
        }

        const data = await dispatch(basketCreate({
            user_id: user.id,
            product_id: el.id,
            quantity: el.quantity,
            price: el.price
        }))

        if (data.payload) {
            toast.success(`${el.title} added in your basket`, {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }

        await dispatch(basketList())
    }, [user])


    const handleLike = useCallback(async (el) => {


        let error = false
        const likeId = likes.map((id) => (id.product_id))

        if (likeId.find((id) => id === el.id)) {
            error = true
            toast.error('Item already in your wishlist!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
        }

        if (!user) {
            toast.error('Please login to be add item in your wishlist!', {
                position: "top-center",
                autoClose: 1000,
                hideProgressBar: false,
                closeOnClick: true,
                pauseOnHover: true,
                draggable: true,
                progress: undefined,
                theme: "dark",
            });
            return
        } else if (error && user) {
            return
        }

        const data = await dispatch(likeProduct({
            product_id: el.id,
            user_id: user.id
        }))
        if (data.payload) {
            toast(`${el.title} added in your wishlist`)
        }

        await dispatch(likeList())
    }, [user])


    const singleItem = useCallback((id) => {
        navigate(`/home/${id}`)
        window.scrollTo({
            top: 0,
            behavior: 'smooth',
        })
    }, [product]);


    const handleMouseMove = (e) => {
        const {left, top, width, height} = e.currentTarget.getBoundingClientRect();
        const x = (e.pageX - left) / width;
        const y = (e.pageY - top) / height;
        setPosition({x, y});
        setZoom(true);
    };

    const handleMouseLeave = () => {
        setZoom(false);
    };

    // const handleRate = useCallback((el) => {
    //     if (el !== 0) {
    //         setRating(el);
    //     } else {
    //         return;
    //     }
    //     console.log(rating);
    // }, [rating]);
    return (
        <>
            {user && user.role === 2 ? <AdminHeader/> : <Header/>}
            <Toast/>
            {product.length ?
                <div className='container'>
                    {product.map((item) => (
                        <div className='singleCardStyle'>
                            <div className="singleCard">
                                <div className='carousel' key={item.id}>
                                    <Carousel wrapAround animation='fade' defaultControlsConfig={{
                                        nextButtonText: <ArrowForwardIosIcon/>,
                                        prevButtonText: <ArrowBackIosNewIcon/>,
                                    }}>
                                        {item.images.map((i) => (
                                            <figure key={i.id}
                                                    onMouseMove={(e) => handleMouseMove(e)}
                                                    onMouseLeave={handleMouseLeave}>
                                                <img className={zoom ? "zoomed" : ""}
                                                     src={i}
                                                     alt="Zoom able Image"
                                                     style={{
                                                         transform: `scale(${zoom ? 2 : 1})`,
                                                         transformOrigin: `${position.x * 100}% ${position.y * 100}%`,
                                                         transition: 'transform 0.4s',
                                                         willChange: 'transform',
                                                         pointerEvents: 'none',
                                                         userSelect: 'none',
                                                     }}
                                                />
                                            </figure>
                                        ))}
                                    </Carousel>
                                </div>

                                <div className="productBody">
                                    <h5 className="productTitle">{item.title}</h5>
                                    <div className='stars'>
                                        <ReactStars
                                            count={5}
                                            size={50}
                                            value={rating}
                                            color='#ccc'
                                            isHalf
                                            classNames='starStyle'
                                            activeColor="#ffd700"
                                        />
                                    </div>
                                    <p className='descriptionPanel'
                                       style={{
                                           overflowY: showScroll ? "scroll" : "hidden",
                                           maxWidth: 350,
                                           width: '100%',
                                           maxHeight: 250
                                       }}>
                                         <span className="productText desc">
                                                  {showAll ? item.description : `${item.description.slice(0, 50)}...`}
                                             {!showAll
                                                 ?
                                                 <button className='moreButton' onClick={handleClickShowAll}>
                                                     Show More
                                                 </button>
                                                 :
                                                 <button className='lessButton' onClick={handleClickHideAll}>
                                                     Show Less
                                                 </button>
                                             }
                                         </span>
                                    </p>
                                </div>
                                {user && user.role !== 2
                                    ? <div className='btnAdd'>
                                        <p className="productPrice">
                                            <CurrencyFormat value={item.price} currency='USD'/>
                                        </p>
                                        <button onClick={() => handleLike(item)} className='addToWishList'>
                                            <FavoriteIcon style={{color: 'red', fontSize: 30}}/>
                                        </button>
                                        <button onClick={() => handleClick(item)} className='addToCard'>
                                            <AddShoppingCartIcon style={{fontSize: 30, verticalAlign: 'middle'}}/> Add
                                            To Cart
                                        </button>
                                    </div>
                                    : null}
                            </div>
                        </div>
                    ))}
                </div>
                :
                null}
            <div className="container">
                <div className='singleProduct'>
                    <h2>Similar products</h2>
                </div>
                <Carousel
                    slidesToShow={4}
                    renderBottomCenterControls={false}
                    defaultControlsConfig={{
                        nextButtonText: <ArrowForwardIosIcon/>,
                        prevButtonText: <ArrowBackIosNewIcon/>,
                    }
                    }
                >
                    {catProd.map((pr) => (
                        <div className='cardStyleBottom'>
                            <div onClick={() => singleItem(pr.id)} key={pr.id} className='cardItemBottom'>
                                <figure className='figure'>
                                    <Card.Img className="productImage" variant='top' src={pr.image}
                                              alt="Cart image cap"/>
                                    <Card.Body className="cardBody">
                                        <Card.Title className="cardTitle">{pr.title}</Card.Title>
                                        <Card.Text className="cardPrice">
                                            <CurrencyFormat value={pr.price} currency='USD'/>
                                        </Card.Text>
                                    </Card.Body>
                                </figure>
                            </div>
                        </div>
                    ))}
                </Carousel>
            </div>
            {user && user.role !== 2 ? <Footer/> : null}
        </>
    )
}
