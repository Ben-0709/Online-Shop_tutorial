import path from "path";
import express from "express";
import cookieParser from "cookie-parser";
import logger from "morgan";
import _ from 'lodash';
import requestData from './middlewares/headers';

import indexRouter from "./routes/index";

const app = express();
app.use(requestData);
app.use(logger("dev"));
app.use(express.json());
app.use(express.urlencoded({extended: false}));
app.use(cookieParser());
app.use(express.static(path.resolve('./public')));
app.use('/images', express.static('public'));
app.use((req, res, next) => {
  let {
    limit,
    offset,
    page,
  } = req.query;

  const pageValue = _.toNumber(page >= 1 ? page : 1);
  const maxLimitValue = 1000;
  const minOffsetValue = 0;
  const minLimitValue = 2;

  limit = _.toNumber(limit >= minLimitValue && limit <= maxLimitValue ? limit : 10);
  offset = page ? (pageValue - 1) * limit : _.toNumber(Math.max(minOffsetValue, offset)) || minOffsetValue;

  req.paginate = {
    limit,
    offset,
    page: pageValue,
  };

  next();
});
app.use('/', indexRouter)

export default app;
