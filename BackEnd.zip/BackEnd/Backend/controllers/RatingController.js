import { Rating, Products } from "../models/index.js";
class RatingController {

  static create = async  (req, res,) => {
    try {
      const {user} = req;
      const { product_id, rate } = req.body;
      const rating = await Rating.create({
        user_id: user.id,
        product_id: product_id,
        rate: rate,
      })
      res.json({
        status: "ok",
        rating,
      })
    }catch (e) {

    }
  };

  static list = async ( req , res ) => {
    try {
       const {product_id }=  req.params;
       const rating = await Rating.findAll({where: { product_id }});
       const product = await Products.findByPk(product_id)
let count = 0;
       for (let i = 0; i < rating.length; i++ ) {
         count+= rating[i].rate
       }
      console.log(count);
      count /= rating.length

   res.json({
     status: "ok",
     product,
     count: Math.round(count),
   });

    }catch (e) {

    }
  };

}

export  default  RatingController
