import {Likes, Products} from "../models/index";

class  LikesController{

  static list = async (req, res, next) =>{
    try {

      const { user } = req;

      const  likes = await Likes.findAll({
        where:{user_id: user.id},
        include:[
          {model: Products}
        ]
      });

      res.json({
        status: "ok",
        likes,
      })
    }catch (e) {
      next(e)
    }
  };


  static index = async (req, res, next) => {
    try {
      const {id} = req.params;
      const likes = await Likes.findOne({
        where: { id },
      });
      res.json({
        status: "ok",
        likes,
      });
    }catch (e){
      next(e);
    }
  };

  static create = async (req, res, next) =>{
    try {
      const { user } = req;

      const { product_id } = req.body;

      const  likes = await Likes.create({
        product_id,
        user_id: user.id,
      });

      res.json({
        status: "ok",
        likes,
      })
    }catch (e){
      next(e);
    }
  };

  static delete = async (req, res, next)=>{
    try {

      const {user} = req;

      const {id} = req.params;
      await Likes.destroy({
        where: {id, user_id: user.id},
      });
      res.json({
        status: "ok",
        message: 'deleted'
      });
    }catch (e){
      next(e);
    }
  };

}

export default  LikesController;
