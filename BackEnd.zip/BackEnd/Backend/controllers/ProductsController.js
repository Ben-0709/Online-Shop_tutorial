import _ from 'lodash';

import {Products} from "../models/index";
import fs from "fs";
import path from "path";
import {v4 as uuidV4} from "uuid";

class ProductsController {
  static list = async (req, res, next) => {
    const {limit, offset, page: currentPage} = req.paginate;
    const {q, cat_id} = req.query
    let where = {};

    if (!_.isEmpty(q)) {
      where = {title: {$like: `%${q}%`}}
    }

    if (!_.isEmpty(cat_id)) {
      where = _.extend(where, {cat_id})
    }
    try {
      const {count: total, rows: products} = await Products.findAndCountAll({where, limit, offset});

      res.json({
        status: "ok",
        products,
        _meta: {
          total,
          currentPage,
          pageCount: Math.ceil(total / limit),
        },
      })
    } catch (e) {
      next(e)
    }
  };
  static index = async (req, res, next) => {
    try {
      const {id} = req.params;
      const product = await Products.findOne({
        where: {id},
      });
      res.json({
        status: "ok",
        product,
      });
    } catch (e) {
      next(e);
    }
  };

  static create = async (req, res, next) => {
    try {
      const {files} = req;

      if (req.user.role !== 2) {
        return res.status(400).json({message: 'Only admin can create'})
      }

      req.body.images = []
      if (!_.isEmpty(files)) {
        files.map((file, index) => {
          const imageName = uuidV4() + '-' + file.originalname;

          const imagePath = path.resolve(path.dirname(''), `public/${imageName}`);

          fs.writeFileSync(imagePath, file.buffer);
          if (index === 0) {
            req.body.image = imageName
          }
          req.body.images.push(imageName);
        })
      }

      const product = await Products.create(req.body);

      res.json({
        status: "ok",
        product,
      })
    } catch (e) {
      next(e);
    }
  };

  static update = async (req, res, next) => {
    const {id} = req.params
    try {
      const product = await Products.update(req.body, {where: {id}});

      res.json({
        status: "ok",
        product: await Products.findByPk(id),
      })
    } catch (e) {
      next(e);
    }
  };

  static delete = async (req, res, next) => {
    try {
      const {id} = req.params;
      await Products.destroy({
        where: {id}
      });
      res.json({
        status: "ok",
        message: 'Product successfully deleted '
      });
    } catch (e) {
      next(e);
    }
  };
}

export default ProductsController;
