import {Orders} from "../models/index";
import Stripe from "stripe";


const { STRIPE_PUBLIC_KEY, STRIPE_SECRET} = process.env;

const stripe =  new Stripe (STRIPE_SECRET);
class OrdersController {
  static getClientSecret = async (req, res, next) => {
    try {
      const paymentIntent = await stripe.paymentIntents.create({
        amount: req.query.amount,
        currency: 'usd',
        payment_method_types:['card']
      });
      res.json({
        status:'ok',
        paymentIntent
      })

    }catch (e) {
      next(e)
    }
  }

  static confirm = async (req, res, next) =>{
    try {
      const {paymentIntent} = req.body;
      const charge = await stripe.paymentIntents.retrieve(paymentIntent)
      res.json({
        status:'ok',
        charge
      })

    }catch (e) {
      next(e)
    }
  }

}

// class OrdersController {
//   static list = async (req, res, next) =>{
//     try {
//       const order = await Orders.findAll();
//       res.json({
//         status: "ok",
//         order,
//       })
//     }catch (e) {
//       next(e)
//     }
//   };
//
//   static index = async (req, res, next) =>{
//     try {
//       const {id} = req.params;
//       const order = await  Orders.findOne({
//         where: { id },
//       });
//       res.json({
//         status: "ok",
//         order,
//       })
//     }catch (e) {
//       next(e)
//     }
//   };
//
//   static create = async (req, res, next) =>{
//     try {
//       const  order = await  Orders.create(req.body);
//
//       res.json({
//         status: "ok",
//         order,
//       })
//     }catch (e) {
//       console.log(e);
//       next(e);
//     }
//   };
//
//   static update = async (req, res, next) =>{
//     const {id} = req.params
//     try {
//       await Orders.update(req.body, {where: {id}});
//
//       res.json({
//         status: "ok",
//         order: await Orders.findByPk(id),
//       })
//     }catch (e){
//       next(e);
//     }
//   };
//
//   static delete = async (req, res, next)=>{
//     try {
//       const {id} = req.params;
//       await Orders.destroy({
//         where: {id}
//       });
//       res.json({
//         status: "ok",
//         message: 'deleted '
//       });
//     }catch (e){
//       console.log(e);
//       next(e);
//     }
//   };
//
// }

export default OrdersController
