import {Basket, Products} from "../models/index";

class BasketController {
  static list = async (req, res, next) =>{
    try {

      const { user } = req;

      const basket = await Basket.findAll({
        where: {user_id: user.id},
        include:[
          { model: Products }
        ]
      });
      res.json({
        status: "ok",
        basket,
      })
    }catch (e) {
      next(e)
    }
  };

  static index = async (req, res, next) =>{
    try {
      const {id} = req.params;
      const basket = await  Basket.findOne({
        where: { id },
      });
      res.json({
        status: "ok",
        basket,
      })
    }catch (e) {
      next(e)
    }
  };

  static create = async (req, res, next) =>{
    try {
      const { user } = req;

      const { product_id, quantity, price, status} = req.body;

    const  basket = await Basket.create({
      product_id,
      quantity,
      price,
      status,
      user_id: user.id,
    });

    res.json({
      status: "ok",
      basket,
    })
    }catch (e) {
      console.log(e);
      next(e);
    }
  };

  static update = async (req, res, next) =>{

    const { user } = req;

    const {id} = req.params;

    try {
      await Basket.update(req.body, { where: { id, user_id: user.id } });

      res.json({
        status: "ok",
        order: await Basket.findByPk(id),
      })
    }catch (e){
      next(e);
    }
  };

  static delete = async (req, res, next)=>{
    try {
      const { user } = req;

      const {id} = req.params;

      await Basket.destroy({
        where: {id, user_id: user.id},
      });
      res.json({
        status: "ok",
        message: 'deleted '
      });
    }catch (e){
      console.log(e);
      next(e);
    }
  };

}

export default BasketController
