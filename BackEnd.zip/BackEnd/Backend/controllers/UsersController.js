import { Users } from "../models/index";
import _ from "lodash";
import HttpError from "http-errors";
import JWT from "jsonwebtoken";

const { JWT_SECRET } = process.env;

class UsersController {
  static list = async (req, res, next) => {
    try {
      const users = await Users.findAll();

      res.json({
        status: "ok",
        users,
      });
    } catch (e) {
      next(e);
    }
  };

  static index = async (req, res, next) => {
    try {
      const { id } = req.params;
      const user = await Users.findOne({
        where: { id },
      });

      res.json({
        status: "ok",
        user,
      });
    } catch (e) {
      next(e);
    }
  };

  static create = async (req, res, next) => {
    try {
      const user = await Users.create(req.body);

      res.json({
        status: "ok",
        user,
      });
    } catch (e) {
      console.log(e);
      next(e);
    }
  };

  static update = async (req, res, next) => {
    const {id} = req.params
    try {
      const user = await Users.update(req.body, {id});

      res.json({
        status: "ok",
        user,
      });
    } catch (e) {
      next(e);
    }
  };

  static delete = async (req, res, next) => {
    try {
      const { id } = req.params;
      await Users.destroy({
        where: { id },
      });

      res.json({
        status: "ok",
        message: 'User successfully deleted'
      });
    } catch (e) {
      next(e);
    }
  };

  static login = async (req, res, next) => {
    try {
      const { email, password } = req.body;
      const user = await Users.findOne({
        where: { email },
      });
      if (
        !user ||
        user.getDataValue("password") !== Users.passwordHash(password)
      ) {
        return res.status(403).json({message: "Invalid email or password"});
      }

      const token = JWT.sign({ userId: user.id, role: user.role }, '123');

      res.json({
        status: "ok",
        user,
        token,
      });
    } catch (e) {
      console.log(e);
      next(e);
    }
  };
}

export default UsersController;
