import {Categories} from "../models/index";

class CategoriesController{
  static list = async (req, res, next) =>{
    try {
      const categories = await Categories.findAll({
        where: { parentId: null },
        include:['child']
      });

      res.json({
        status: "ok",
        categories,
      })
    }catch (e){
      next(e)
    }
  };
  static index = async (req, res, next) => {
    try {
      const {id} = req.params;
      const categories = await Categories.findOne({
        where: { id },
      });
      res.json({
        status: "ok",
        categories,
      });
    }catch (e){
      next(e);
    }
  };

  static create = async (req, res, next) =>{
    try {
      if (req.user.role !== 2){
        return res.status(400).json({message: 'Only admin can create'})
      }
      const  categories = await Categories.create(req.body);

      res.json({
        status: "ok",
        categories,
      })
    }catch (e){
      next(e);
    }
  };


  static update = async (req, res, next) =>{
    const {id} = req.params
    try {
      const categories = await Categories.update(req.body, {id});

      res.json({
        status: "ok",
        categories,
      })
    }catch (e){
      next(e);
    }
  };

  static delete = async (req, res, next)=>{
    try {
      const {id} = req.params;
      await Categories.destroy({
        where: {id}
      });
      res.json({
        status: "ok",
        message: 'Categories successfully deleted '
      });
    }catch (e){
      next(e);
    }
  };
}

export default CategoriesController;
