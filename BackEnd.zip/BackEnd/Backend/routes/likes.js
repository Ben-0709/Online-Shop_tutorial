import express from "express";
import authorization from "../middlewares/authorization.js";

import LikesController from './../controllers/LikesController'


const router = express.Router();

router.get('/',authorization, LikesController.list)
router.get('/:id',authorization, LikesController.index)
router.post('/',authorization, LikesController.create)
router.delete('/:id',authorization, LikesController.delete)



export default router;
