import express from "express";

import OrdersController from '../controllers/OrdersController';
import authorization from "../middlewares/authorization.js";

const router = express.Router();

router.get("/client-secret", authorization, OrdersController.getClientSecret);
router.post("/confirm", authorization, OrdersController.confirm)


export default router;
