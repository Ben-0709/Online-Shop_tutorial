import express from "express";
import authorization from "../middlewares/authorization.js";



import ProductsController from "./../controllers/ProductsController";
import multerUploader from "../services/multerUploader";


const router = express.Router();

router.get('/', ProductsController.list)
router.get('/:id', ProductsController.index)
router.post('/', authorization, multerUploader.array('files', 10), ProductsController.create)
router.put('/:id', ProductsController.update)
router.delete('/:id', ProductsController.delete)



export default  router;
