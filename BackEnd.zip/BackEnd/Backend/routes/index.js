import express from "express";

import users from "./users";
import products from "./products";
import categories from "./categories";
import basket from "./basket";
import likes from "./likes";
import orders from "./orders";
import rating from "./rating"
const router = express.Router();

router.use("/users", users);
router.use("/products", products);
router.use("/categories", categories);
router.use("/orders", orders);
router.use("/basket", basket);
router.use("/rating", rating);
router.use("/likes", likes);
router.use("/basket", basket);

export default router;

