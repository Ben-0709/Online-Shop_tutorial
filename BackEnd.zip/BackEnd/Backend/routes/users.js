import express from "express";

import UsersController from './../controllers/UsersController'

const router = express.Router();

router.get('/', UsersController.list)
router.get('/:id', UsersController.index)
router.post('/', UsersController.create)
router.post('/login', UsersController.login)
router.put('/', UsersController.update)
router.delete('/:id', UsersController.delete)

export default router;
