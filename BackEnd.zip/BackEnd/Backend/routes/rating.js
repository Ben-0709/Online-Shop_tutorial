import express from "express";
import authorization from "../middlewares/authorization.js";

import RatingController from "../controllers/RatingController.js";


const router = express.Router();

router.get('/:product_id', authorization, RatingController.list)
router.post('/', authorization, RatingController.create)

export default router;
