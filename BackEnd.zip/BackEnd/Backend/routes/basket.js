import express from "express";
import authorization from "../middlewares/authorization.js";

import BasketController from '../controllers/BasketController'

const router = express.Router();

router.get('/list', authorization, BasketController.list)
router.get('/:id', authorization, BasketController.index)
router.post('/create', authorization, BasketController.create)
router.put('/:id', authorization, BasketController.update)
router.delete('/:id', authorization, BasketController.delete)

export default router;
