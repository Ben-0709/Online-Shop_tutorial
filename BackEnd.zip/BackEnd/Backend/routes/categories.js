import express from "express";


import CategoriesController from "./../controllers/CategoriesController"
import authorization from "../middlewares/authorization.js";


const router = express.Router();

router.get('/', CategoriesController.list)
router.get('/:id', CategoriesController.index)
router.post('/', authorization, CategoriesController.create)
router.put('/', CategoriesController.update)
router.delete('/', CategoriesController.delete)



export default  router;
