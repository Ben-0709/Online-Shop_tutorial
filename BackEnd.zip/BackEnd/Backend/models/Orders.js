import { DataTypes, Model } from "sequelize";
import sequelize from "../services/sequelize";


class Orders extends Model {
}

Orders.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    payment_method: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    basket_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    modelName: "orders",
    tableName: "orders",
    timestamps: false,
    sequelize,
  }
);

export default Orders;
