import { DataTypes, Model} from "sequelize";
import sequelize from "../services/sequelize.js";


class Rating extends Model{
}

Rating.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    rate: {
      type: DataTypes.INTEGER
    }
  },
  {
    modelName: "rating",
    tableName: "rating",
    timestamps: false,
    sequelize,
  }
)

export  default Rating
