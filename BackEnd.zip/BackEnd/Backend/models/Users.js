import { DataTypes, Model } from "sequelize";
import sequelize from "../services/sequelize";
import md5 from "md5";

class Users extends Model {
  static passwordHash = (password) => md5(md5(password) + "234hjh42jh54hj423");
}

Users.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      autoIncrement: true,
      primaryKey: true,
    },
    username: {
      type: DataTypes.STRING,
    },
    fname: {
      type: DataTypes.STRING,
    },
    lname: {
      type: DataTypes.STRING,
    },
    age: {
      type: DataTypes.INTEGER,
    },
    role: {
      type: DataTypes.INTEGER,
      defaultValue: 6
    },
    email: {
      type: DataTypes.STRING,
      allowNull: false,
      unique: "email",
    },
    password: {
      type: DataTypes.CHAR(32),
      allowNull: true,
      get() {
        return undefined;
      },

      set(val) {
        if (val) {
          this.setDataValue("password", Users.passwordHash(val));
        }
      },
    },
  },
  {
    modelName: "users",
    tableName: "users",
    timestamps: false,
    sequelize,
  }
);

export default Users;
