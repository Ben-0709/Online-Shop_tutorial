import { DataTypes, Model } from "sequelize";
import sequelize from "../services/sequelize";
import Products from "./Products.js";

class Likes extends Model {
}

Likes.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
  },
  {
    modelName: "likes",
    tableName: "likes",
    timestamps: false,
    sequelize,
  }
);

Likes.belongsTo(Products,{
  foreignKey:"product_id"
})

export default Likes;
