import { DataTypes, Model } from "sequelize";
import sequelize from "../services/sequelize";

class Categories extends Model {
}

Categories.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    title: {
      type: DataTypes.STRING,
    },
    parentId: {
      type: DataTypes.BIGINT,
    },
  },
  {
    modelName: "categories",
    tableName: "categories",
    timestamps: false,
    sequelize,
  }
);

Categories.hasMany(Categories, {
  as: 'child',
  foreignKey: 'parentId',
})
export default Categories;
