import { DataTypes, Model } from "sequelize";
import sequelize from "../services/sequelize";
import Products from "./Products";


class Basket extends Model {
}

Basket.init(
  {
    id: {
      type: DataTypes.BIGINT.UNSIGNED,
      allowNull: false,
      autoIncrement: true,
      primaryKey: true,
    },
    user_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    product_id: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    quantity: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    price: {
      type: DataTypes.INTEGER,
      allowNull: false,
    },
    status: {
      type: DataTypes.STRING,
      defaultValue: 'pending',
    },
  },
  {
    modelName: "basket",
    tableName: "basket",
    timestamps: false,
    sequelize,
  }
);

Basket.belongsTo(Products, {
  foreignKey: "product_id",
})

export default Basket;
