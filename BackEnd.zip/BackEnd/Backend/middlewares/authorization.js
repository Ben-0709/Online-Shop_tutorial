import JWT from "jsonwebtoken";
import dotenv from 'dotenv'
dotenv.config()
const EXCLUDE = ["/users/login", "/users/register", "/orders/client-secret", "/orders/confirm"];
const { JWT_SECRET } = process.env;

export default function authorization(req, res, next) {
  try {
    const { authorization = "" } = req.headers;
    const { method } = req;
    if (method === 'OPTIONS' || EXCLUDE.includes(req.path)) {
      next();
      return;
    }
    const { userId, role } = JWT.verify(
      authorization.replace("Bearer ", ""),
      JWT_SECRET
    );

    req.user = {
      id: userId,
      role
    };

    next();
  } catch (e) {
    e.status = 401;
    next(e);
  }
}
