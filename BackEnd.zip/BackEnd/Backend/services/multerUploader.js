import multer from "multer";

const multerUploader = multer({
  storage: multer.memoryStorage(),
   limits:{
    fields: 1024 * 1024 * 10,
    fieldSize: 1024 * 1024 * 10,
    fileSize: 1024 * 1024 * 10,
   },
});

export default multerUploader;
